/**
 * Lab 2 for CS 1181
 * @author Jonathan Dotson
 * This lab shows an understanding of how to create a usable GUI with multiple Panes
 * and an understanding of how to make events.
 */
package dotson_lab2;
/**

* @author Jonathan Dotson

* CS1181L-06

* Instructor: R. Volkers

* TA: Alton Panton  

*/
import java.awt.Color;
import java.util.Arrays;
import javafx.application.Application;
import javafx.embed.swing.SwingNode;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundFill;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.CornerRadii;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.ScrollPaneConstants;

/**
 *
 * @author Jonathan
 */


public class Dotson_lab2 extends Application {
    
    public TextField currency = new TextField();
    private Label amount = new Label("Enter a currency amount");
    private Label input = new Label("Input Currency");
    private Label output2 = new Label("Output Currency");
    private Label output = new Label("Converted Currency");
    private TextField convert = new TextField();
    private JTextArea error = new JTextArea("Error Messages", 15, 20);
    private SwingNode swingnode = new SwingNode();
    ToggleGroup group2;
    ToggleGroup group;
    RadioButton usd2;
    RadioButton cad2;
    RadioButton pound2;
    RadioButton euro2;
    RadioButton yen2;
    
    @Override
    public void start(Stage primaryStage) {
        /**
     * @param currency The input TextField for the user, can only take positive numbers
     * @param amount The Label for the currency TextField
     * @param input The Label for the VBox on the left
     * @param output2 The Label for the output TextField on the bottom panel.
     * @param output The Label for the VBox on the right
     * @param convert The output TextField, shows the converted value.
     * @param error The TextArea that shows errors if there are any.
     * @param swingmode Allows the JTextArea to be placed into the root BorderPane.
     * @param group2 The set of RadioButtons set to the VBox on the right. Only allows 
     * one to chosen at a time
     * @param group The set of RadioButtons set to the VBox on the left. Only allows 
     * one to chosen at a time.
     * @param usd2 US Dollars right-sided VBox RadioButton
     * @param cad2 Canadian Dollars right-sided VBox RadioButton
     * @param pound2 UK pounds, right-sided VBox RadioButton
     * @param euro2 European Euros, right-sided VBox RadioButton
     * @param yen2 Japanese Yen, right-sided VBox RadioButton
     * @param root The main component of the GUI, adds everything to all of the children of the BorderPane
     * @param usd US Dollars left-sided VBox RadioButton
     * @param cad Canadian Dollars left-sided VBox RadioButton
     * @param pound UK pounds, left-sided VBox RadioButton
     * @param euro European Euros, left-sided VBox RadioButton
     * @param yen Japanese Yen, left-sided VBox RadioButton
     */
        convert.setEditable(false);
        JPanel centerJPanel = new JPanel();
        JScrollPane err = new JScrollPane(error);
        error.setEditable(false);
        VBox vbox = new VBox(8);
        VBox vbox2 = new VBox(8);
        vbox2.setSpacing(10);
        vbox.setSpacing(10);
        HBox hbox = new HBox(8);
        HBox hbox2 = new HBox(8);
        hbox2.setAlignment(Pos.BOTTOM_RIGHT);
        BorderPane root = new BorderPane();
        currency.setMaxWidth(200);
        convert.setMaxWidth(200);
        
        group = new ToggleGroup();
        RadioButton usd = new RadioButton("US Dollar");
        usd.setToggleGroup(group);
        
        RadioButton euro = new RadioButton("European Euro");
        euro.setToggleGroup(group);
        
        RadioButton pound = new RadioButton("British Pound");
        pound.setToggleGroup(group);
        
        RadioButton cad = new RadioButton("Canadian Dollar");
        cad.setToggleGroup(group);
        
        RadioButton yen = new RadioButton("Japanese Yen");
        yen.setToggleGroup(group);
        
        group2 = new ToggleGroup();
        
        usd2 = new RadioButton("US Dollar");
        usd2.setToggleGroup(group2);
        
        euro2 = new RadioButton("European Euro");
        euro2.setToggleGroup(group2);
        
        pound2 = new RadioButton("British Pound");
        pound2.setToggleGroup(group2);
        
        cad2 = new RadioButton("Canadian Dollar");
        cad2.setToggleGroup(group2);
        /**
         * Giving each of the group variables a UserData value in order to use the switch
         * later on.
         */
        usd.setUserData("usd");
        euro.setUserData("euro");
        pound.setUserData("pound");
        cad.setUserData("cad");
        yen.setUserData("yen");
        
        yen2 = new RadioButton("Japanese Yen");
        yen2.setToggleGroup(group2);
        currency.setOnKeyPressed((KeyEvent event) -> {
            String inputString = currency.getText();
            double validatedDouble;
            
            if (event.getCode() == KeyCode.ENTER) {
                try {
                    Double conv = Double.valueOf(inputString);
                    validatedDouble = conv;
                    if(validatedDouble < 0){
                        error.setText("Only input positive numbers");
                        currency.setText("0");
                        convert.setText("");
                    }
                    updateCurrency(validatedDouble);
                } catch (Exception e) {
                    error.setText("Only input positive numbers");
                    currency.setText("0");
                    convert.setText("");
                }
                System.out.println("Enter Pressed");
            }
        });
        
        centerJPanel.add(err);
        err.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
        swingnode.setContent(centerJPanel);
        vbox.getChildren().addAll(input, usd, euro, pound, cad, yen);
        hbox.getChildren().addAll(amount, currency);
        vbox2.getChildren().addAll(output2, usd2, euro2, pound2, cad2, yen2);
        hbox2.getChildren().addAll(output, convert);
        root.setCenter(swingnode);
        root.setTop(hbox);
        root.setLeft(vbox);
        root.setRight(vbox2);
        root.setBottom(hbox2);
        
        Scene scene = new Scene(root, 500, 350);
        primaryStage.setTitle("Currency Conversion");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        launch(args);
    }
    
    public void updateCurrency(double input) {
        switch (group.getSelectedToggle().getUserData().toString()) {
            case "usd":
                if (group2.getSelectedToggle() == usd2) {
                    convert.setText(String.valueOf(input));
                    break;
                } else if (group2.getSelectedToggle() == euro2) {
                    
                    convert.setText(String.valueOf(input * .828));
                    break;
                } else if (group2.getSelectedToggle() == pound2) {
                    convert.setText(String.valueOf(input * .738));
                    break;
                } else if (group2.getSelectedToggle() == cad2) {
                    convert.setText(String.valueOf(input * 1.253));
                    break;
                } else if (group2.getSelectedToggle() == yen2) {
                    convert.setText(String.valueOf(input * 112.80));
                    break;
                }
            case "euro":
                if (group2.getSelectedToggle() == usd2) {
                    convert.setText(String.valueOf(input * 1.20773));
                    break;
                } else if (group2.getSelectedToggle() == euro2) {
                    convert.setText(String.valueOf(input));
                    break;
                } else if (group2.getSelectedToggle() == pound2) {
                    convert.setText(String.valueOf(input * .8913));
                    break;
                } else if (group2.getSelectedToggle() == cad2) {
                    convert.setText(String.valueOf(input * 1.5));
                    break;
                } else if (group2.getSelectedToggle() == yen2) {
                    convert.setText(String.valueOf(input * 136.2319));
                    break;
                }
            case "pound":
                if (group2.getSelectedToggle() == usd2) {
                    convert.setText(String.valueOf(input * 1.35501));
                    break;
                } else if (group2.getSelectedToggle() == euro2) {
                    convert.setText(String.valueOf(input * 1.12195));
                    break;
                } else if (group2.getSelectedToggle() == pound2) {
                    convert.setText(String.valueOf(input));
                    break;
                } else if (group2.getSelectedToggle() == cad2) {
                    convert.setText(String.valueOf(input * 1.69783));
                    break;
                } else if (group2.getSelectedToggle() == yen2) {
                    convert.setText(String.valueOf(input * 152.8455));
                    break;
                }
            case "cad":
                if (group2.getSelectedToggle() == usd2) {
                    convert.setText(String.valueOf(input * 0.79808));
                    break;
                } else if (group2.getSelectedToggle() == euro2) {
                    convert.setText(String.valueOf(input * 0.66081));
                    break;
                } else if (group2.getSelectedToggle() == pound2) {
                    convert.setText(String.valueOf(input * 0.588986));
                    break;
                } else if (group2.getSelectedToggle() == cad2) {
                    convert.setText(String.valueOf(input));
                    break;
                } else if (group2.getSelectedToggle() == yen2) {
                    convert.setText(String.valueOf(input * 90.0239));
                    break;
                }
            case "yen":
                if (group2.getSelectedToggle() == usd2) {
                    convert.setText(String.valueOf(input * 0.008865));
                    break;
                } else if (group2.getSelectedToggle() == euro2) {
                    convert.setText(String.valueOf(input * 0.00734));
                    break;
                } else if (group2.getSelectedToggle() == pound2) {
                    convert.setText(String.valueOf(input * 0.006543));
                    break;
                } else if (group2.getSelectedToggle() == cad2) {
                    convert.setText(String.valueOf(input * 0.011108));
                    break;
                } else if (group2.getSelectedToggle() == yen2) {
                    convert.setText(String.valueOf(input));
                    break;
                }
                    
                
        }
        
    }
}
